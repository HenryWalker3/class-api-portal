---
title: Terms
description: Legal terms for using the API
---

# Terms

Use of the API is governed by the YourCompany Developer Terms of Service.
