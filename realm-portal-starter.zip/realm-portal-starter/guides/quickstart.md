---
title: Quickstart
description: End‑to‑end flow
---

# Quickstart

This guide walks you through an end-to-end flow:
1. Authenticate with OAuth 2.0 (Authorization Code).
2. Retrieve resources via the REST API.
3. Handle pagination and webhooks.
